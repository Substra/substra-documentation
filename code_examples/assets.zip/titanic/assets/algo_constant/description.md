# Constant death predictor

This algorithm always predicts that passengers of the Titanic will die, with no regard for any data whatsoever.