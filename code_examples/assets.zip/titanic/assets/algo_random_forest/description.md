# Titanic random forest

Better performance through the usage of a Random Forest classifier.

Based on Niklas Donges' article, [Predicting the Survival of Titanic Passengers](https://towardsdatascience.com/predicting-the-survival-of-titanic-passengers-30870ccc7e8)
